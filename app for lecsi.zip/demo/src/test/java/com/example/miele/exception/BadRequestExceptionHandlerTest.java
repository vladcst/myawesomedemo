package com.example.miele.exception;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.test.context.TestPropertySource;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;

@RunWith(MockitoJUnitRunner.class)
@TestPropertySource(locations = "/test.properties")
public class BadRequestExceptionHandlerTest {

    @Test
    public void testHandleMethodArgumentNotValid() {
	// given
	BadRequestExceptionHandler badRequestExceptionHandler = new BadRequestExceptionHandler();
	MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);
	BindingResult bindingResult = mock(BindingResult.class);
	List<ObjectError> objectErrors = new ArrayList<>();

	when(ex.getBindingResult()).thenReturn(bindingResult);
	when(ex.getBindingResult().getAllErrors()).thenReturn(objectErrors);
	ResponseEntity<Object> response = badRequestExceptionHandler.methodArgumentNotValidException(ex);

	// then
	assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
    }

    @Test
    public void testHandleHttpMediaTypeNotSupported() {
	// given
	BadRequestExceptionHandler badRequestExceptionHandler = new BadRequestExceptionHandler();
	HttpMediaTypeNotSupportedException ex = mock(HttpMediaTypeNotSupportedException.class);

	ResponseEntity<Object> response = badRequestExceptionHandler.handleHttpMediaTypeNotSupported(ex);

	// then
	assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
    }

    @Test
    public void testHandleHttpMessageNotReadable() {
	// given
	BadRequestExceptionHandler badRequestExceptionHandler = new BadRequestExceptionHandler();
	HttpMessageNotReadableException ex = mock(HttpMessageNotReadableException.class);

	ResponseEntity<Object> response = badRequestExceptionHandler.handleHttpMessageNotReadable(ex);

	// then
	assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
    }

}
