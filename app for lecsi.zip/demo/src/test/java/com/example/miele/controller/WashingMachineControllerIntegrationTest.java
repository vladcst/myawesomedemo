package com.example.miele.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.example.miele.dto.WashingMachineRequestDTO;
import com.example.miele.dto.WashingMachineResponseDTO;
import com.example.miele.service.WashingMachineService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@RunWith(SpringRunner.class)
@WebMvcTest(WashingMachineController.class)
@TestPropertySource(locations = "/application-test.properties")
public class WashingMachineControllerIntegrationTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private WashingMachineService washingMachineService;

    public static String asJsonString(final Object obj) {
	ObjectMapper mapper = new ObjectMapper();
	mapper.registerModule(new JavaTimeModule());
	mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	try {
	    return mapper.writeValueAsString(obj);
	} catch (Exception e) {
	    throw new RuntimeException(e);
	}
    }

    @Test
    public void whenGetWashingMachineById_returnWashingMachineWithStatusOK() throws Exception {
	String id = "d7cd23b8-test-470f-ac63-d8fb106f391e";

	WashingMachineResponseDTO washingMachineResponse = new WashingMachineResponseDTO();
	washingMachineResponse.setId("d7cd23b8-test-470f-ac63-d8fb106f391e");
	washingMachineResponse.setCapacity(12);
	washingMachineResponse.setColor("Black Noir");
	washingMachineResponse.setDescription("One of the best washing machines in the market.");
	washingMachineResponse.setManufacturingDate(LocalDateTime.of(2020, 12, 12, 15, 00, 00));
	washingMachineResponse.setDryerIncorporated(false);

	when(washingMachineService.findWashingMachineById(ArgumentMatchers.anyString()))
		.thenReturn(washingMachineResponse);

	mvc.perform(MockMvcRequestBuilders.get("/washingMachine/{id}", id)).andExpect(status().isOk())
		.andExpect(jsonPath("$.id", is(id)))
		.andExpect(jsonPath("$.capacity", is(washingMachineResponse.getCapacity())))
		.andExpect(jsonPath("$.color", is(washingMachineResponse.getColor())))
		.andExpect(jsonPath("$.dryerIncorporated", is(washingMachineResponse.getDryerIncorporated())))
		.andExpect(jsonPath("$.manufacturingDate", is(washingMachineResponse.getManufacturingDate())))
		.andExpect(jsonPath("$.description", is(washingMachineResponse.getDescription()))).andReturn();
    }

    @Test
    public void whenGetWashingMachines_returnAllWashingMachinesWithStatusOK() throws Exception {
	WashingMachineResponseDTO washingMachineResponse = new WashingMachineResponseDTO();
	washingMachineResponse.setId("d7cd23b8-test-470f-ac63-d8fb106f391e");
	washingMachineResponse.setCapacity(12);
	washingMachineResponse.setColor("Black Noir");
	washingMachineResponse.setDescription("One of the best washing machines in the market.");
	washingMachineResponse.setManufacturingDate(LocalDateTime.of(2020, 12, 12, 15, 00, 00));
	washingMachineResponse.setDryerIncorporated(false);

	List<WashingMachineResponseDTO> allWashingMachines = new ArrayList<>();
	allWashingMachines.add(washingMachineResponse);

	when(washingMachineService.findAllWashingMachines()).thenReturn(allWashingMachines);

	mvc.perform(MockMvcRequestBuilders.get("/washingMachine")).andExpect(status().isOk()).andReturn();
    }

    @Test
    public void whenGetWashingMachinesNotFound_returnEmptyWithStatusNoContent() throws Exception {
	List<WashingMachineResponseDTO> emptyList = new ArrayList<>();

	when(washingMachineService.findAllWashingMachines()).thenReturn(emptyList);

	mvc.perform(MockMvcRequestBuilders.get("/washingMachine")).andExpect(status().isNoContent())
		.andExpect(jsonPath("$").doesNotExist()).andReturn();
    }

    @Test
    public void whenSaveWashingMachine_returnWashingMachineWithStatusCreated() throws Exception {
	WashingMachineRequestDTO washingMachineRequest = new WashingMachineRequestDTO();
	washingMachineRequest.setCapacity(12);
	washingMachineRequest.setColor("Black Noir");
	washingMachineRequest.setDescription("One of the best washing machines in the market.");
	washingMachineRequest.setManufacturingDate(LocalDateTime.of(2020, 12, 12, 15, 00, 00));
	washingMachineRequest.setDryerIncorporated(false);

	WashingMachineResponseDTO washingMachineResponse = new WashingMachineResponseDTO();
	washingMachineResponse.setId("d7cd23b8-test-470f-ac63-d8fb106f391e");
	washingMachineResponse.setCapacity(12);
	washingMachineResponse.setColor("Black Noir");
	washingMachineResponse.setDescription("One of the best washing machines in the market.");
	washingMachineResponse.setManufacturingDate(LocalDateTime.of(2020, 12, 12, 15, 00, 00));
	washingMachineResponse.setDryerIncorporated(false);

	when(washingMachineService.saveWashingMachine(washingMachineRequest)).thenReturn(washingMachineResponse);

	mvc.perform(MockMvcRequestBuilders.post("/ishClassicClientManagement/clientConfiguration")
		.content(asJsonString(washingMachineRequest)).contentType(MediaType.APPLICATION_JSON))
		.andExpect(jsonPath("$.capacity", is(washingMachineRequest.getCapacity())))
		.andExpect(jsonPath("$.color", is(washingMachineRequest.getColor())))
		.andExpect(jsonPath("$.dryerIncorporated", is(washingMachineRequest.getDryerIncorporated())))
		.andExpect(jsonPath("$.manufacturingDate", is(washingMachineRequest.getManufacturingDate())))
		.andExpect(jsonPath("$.description", is(washingMachineRequest.getDescription()))).andReturn();
    }

    @Test
    public void whenUpdateWashingMachine_returnEmptyBodyWithStatusNoContent() throws Exception {
	String id = "d7cd23b8-test-470f-ac63-d8fb106f391e";

	WashingMachineRequestDTO washingMachineRequest = new WashingMachineRequestDTO();
	washingMachineRequest.setCapacity(12);
	washingMachineRequest.setColor("Black Noir");
	washingMachineRequest.setDescription("One of the best washing machines in the market.");
	washingMachineRequest.setManufacturingDate(LocalDateTime.of(2020, 12, 12, 15, 00, 00));
	washingMachineRequest.setDryerIncorporated(false);

	doNothing().when(washingMachineService).updateWashingMachineById(id, washingMachineRequest);

	mvc.perform(MockMvcRequestBuilders.put("/washingMachine/{id}", id).content(asJsonString(washingMachineRequest))
		.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isNoContent())
		.andExpect(jsonPath("$").doesNotExist()).andReturn();
    }

    @Test
    public void whenDeleteWashingMachine_deleteWashingMachineAndReturnStatusNoContent() throws Exception {
	String id = "d7cd23b8-test-470f-ac63-d8fb106f391e";

	doNothing().when(washingMachineService).deleteWashingMachineById(id);

	mvc.perform(MockMvcRequestBuilders.delete("/washingMachine/{id}", id)).andExpect(status().isNoContent())
		.andExpect(jsonPath("$").doesNotExist()).andReturn();
    }

}
