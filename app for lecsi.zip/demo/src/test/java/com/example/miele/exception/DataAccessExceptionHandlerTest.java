package com.example.miele.exception;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.context.request.WebRequest;

@RunWith(MockitoJUnitRunner.class)
@TestPropertySource(locations = "/test.properties")
public class DataAccessExceptionHandlerTest {

    @Test
    public void testDataAccessExceptionHandler() {
	// given
	DataAccessExceptionHandler dataAccessExceptionHandler = new DataAccessExceptionHandler();
	DataAccessException ex = mock(DataAccessException.class);
	WebRequest request = mock(WebRequest.class);

	ResponseEntity<Object> response = dataAccessExceptionHandler.dataAccessExceptionHandler(ex, request);

	// then
	assertEquals(response.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
