package com.example.miele.exception;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import javax.persistence.EntityNotFoundException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.context.request.WebRequest;

@RunWith(MockitoJUnitRunner.class)
@TestPropertySource(locations = "/test.properties")
public class ResourceNotFoundExceptionHandlerTest {

    @Test
    public void testDataAccessExceptionHandler() {
	// given
	ResourceNotFoundExceptionHandler resourceNotFoundExceptionHandler = new ResourceNotFoundExceptionHandler();
	EntityNotFoundException ex = mock(EntityNotFoundException.class);
	WebRequest request = mock(WebRequest.class);

	ResponseEntity<Object> response = resourceNotFoundExceptionHandler.entityNotFoundExceptionHandler(ex, request);

	// then
	assertEquals(response.getStatusCode(), HttpStatus.NOT_FOUND);
    }
}
