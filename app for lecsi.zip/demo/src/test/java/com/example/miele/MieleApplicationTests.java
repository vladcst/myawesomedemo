package com.example.miele;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MieleApplicationTests {

	@Test
	void contextLoads() {
	}

}
