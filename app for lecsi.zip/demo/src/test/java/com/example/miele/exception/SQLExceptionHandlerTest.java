package com.example.miele.exception;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import java.sql.SQLNonTransientException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.context.request.WebRequest;

@RunWith(MockitoJUnitRunner.class)
@TestPropertySource(locations = "/test.properties")
public class SQLExceptionHandlerTest {

    @Test
    public void testSQLExceptionHandler() {
	// given
	SQLExceptionHandler sqlExceptionHandler = new SQLExceptionHandler();
	SQLNonTransientException ex = mock(SQLNonTransientException.class);
	WebRequest request = mock(WebRequest.class);

	ResponseEntity<Object> response = sqlExceptionHandler.sqlExceptionHandler(ex, request);

	// then
	assertEquals(response.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
