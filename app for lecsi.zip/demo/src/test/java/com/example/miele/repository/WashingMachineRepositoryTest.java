package com.example.miele.repository;

import static org.junit.jupiter.api.Assertions.assertAll;

import java.time.LocalDateTime;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.miele.entity.WashingMachine;

@RunWith(SpringRunner.class)
@DataJpaTest
@TestPropertySource(locations = "/application-test.properties")
public class WashingMachineRepositoryTest {

    @Autowired
    private WashingMachineRepository washingMachineRepository;

    private WashingMachine washingMachine;

    @Before
    public void setUp() {
	washingMachine = new WashingMachine();
	washingMachine.setCapacity(10);
	washingMachine.setColor("White");
	washingMachine.setDescription("One of the best washing machines in the market.");
	washingMachine.setManufacturingDate(LocalDateTime.of(2020, 3, 2, 14, 12, 42));
	washingMachine.setDryerIncorporated(true);
    }

    @Test
    public void whenfindWashingMachineByID_thenReturnWashingMachine() {
	washingMachineRepository.save(washingMachine);
	assertAll(() -> Optional.ofNullable(washingMachineRepository.findWashingMachineById(washingMachine.getId())
		.orElseThrow(RuntimeException::new)));
    }

}
