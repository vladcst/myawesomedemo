package com.example.miele.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.TestPropertySource;

import com.example.miele.dto.WashingMachineRequestDTO;
import com.example.miele.dto.WashingMachineResponseDTO;
import com.example.miele.entity.WashingMachine;
import com.example.miele.repository.WashingMachineRepository;
import com.example.miele.service.impl.WashingMachineServiceImpl;

@RunWith(MockitoJUnitRunner.class)
@TestPropertySource(locations = "/test.properties")
public class WashingMachineServiceImplTest {

    @MockBean
    private ModelMapper modelMapper;

    @Mock
    private WashingMachineRepository washingMachineRepository;

    @InjectMocks
    private WashingMachineServiceImpl washingMachineService;

    private WashingMachine washingMachine;
    private WashingMachineResponseDTO washingMachineResponse;

    @Before
    public void setUp() {

	washingMachine = new WashingMachine();
	washingMachine.setId("d7cd23b8-test-470f-ac63-d8fb106f391e");
	washingMachine.setCapacity(12);
	washingMachine.setColor("Black Noir");
	washingMachine.setDescription("One of the best washing machines in the market.");
	washingMachine.setManufacturingDate(LocalDateTime.of(2020, 12, 12, 15, 00, 00));
	washingMachine.setDryerIncorporated(false);

	washingMachineResponse = new WashingMachineResponseDTO();
	washingMachineResponse.setId("d7cd23b8-test-470f-ac63-d8fb106f391e");
	washingMachineResponse.setCapacity(12);
	washingMachineResponse.setColor("Black Noir");
	washingMachineResponse.setDescription("One of the best washing machines in the market.");
	washingMachineResponse.setManufacturingDate(LocalDateTime.of(2020, 12, 12, 15, 00, 00));
	washingMachineResponse.setDryerIncorporated(false);
    }

    @Test
    public void testFindWashingMachineById() {
	// given
	String id = "d7cd23b8-test-470f-ac63-d8fb106f391e";
	when(washingMachineRepository.findWashingMachineById(id)).thenReturn(Optional.of(washingMachine));
	when(modelMapper.map(washingMachine, WashingMachineResponseDTO.class)).thenReturn(washingMachineResponse);

	// when
	WashingMachineResponseDTO response = washingMachineService.findWashingMachineById(id);

	// then
	assertEquals(id, response.getId());
    }

    @Test(expected = EntityNotFoundException.class)
    public void testFindWashingMachineByIdNotFound() {
	// given
	String id = "d7cd23b8-test-470f-ac63-d8fb106f391e";
	when(washingMachineRepository.findWashingMachineById(id)).thenReturn(Optional.empty());

	// when
	washingMachineService.findWashingMachineById(id);
    }

    @Test
    public void testFindAllWashingMachinesInLaundry() {

	List<WashingMachine> washingMachines = new ArrayList<>();
	washingMachines.add(washingMachine);

	when(washingMachineRepository.findAll()).thenReturn(washingMachines);
	when(modelMapper.map(washingMachine, WashingMachineResponseDTO.class)).thenReturn(washingMachineResponse);

	List<WashingMachineResponseDTO> responseList = washingMachineService.findAllWashingMachines();

	assertEquals(washingMachine.getId(), responseList.get(0).getId());
	assertEquals(washingMachine.getCapacity(), responseList.get(0).getCapacity());
	assertEquals(washingMachine.getDescription(), responseList.get(0).getDescription());
	assertEquals(washingMachine.getColor(), responseList.get(0).getColor());
	assertEquals(washingMachine.isDryerIncorporated(), responseList.get(0).isDryerIncorporated());
	assertEquals(washingMachine.getManufacturingDate(), responseList.get(0).getManufacturingDate());

    }

    @Test
    public void testSaveWashingMachine() {
	// given
	WashingMachineRequestDTO washingMachineRequest = new WashingMachineRequestDTO();
	washingMachineRequest.setCapacity(12);
	washingMachineRequest.setColor("Black Noir");
	washingMachineRequest.setDescription("One of the best washing machines in the market.");
	washingMachineRequest.setManufacturingDate(LocalDateTime.of(2020, 12, 12, 15, 00, 00));
	washingMachineRequest.setDryerIncorporated(false);

	when(modelMapper.map(washingMachineRequest, WashingMachine.class)).thenReturn(washingMachine);
	when(washingMachineRepository.save(washingMachine)).thenReturn(ArgumentMatchers.any(WashingMachine.class));

	// when
	WashingMachineResponseDTO responseFromService = washingMachineService.saveWashingMachine(washingMachineRequest);

	// then
	assertEquals(responseFromService.getDescription(), washingMachineRequest.getDescription());
	assertEquals(responseFromService.getCapacity(), washingMachineRequest.getCapacity());
	assertEquals(responseFromService.getColor(), washingMachineRequest.getColor());
	assertEquals(responseFromService.isDryerIncorporated(), washingMachineRequest.isDryerIncorporated());
	assertEquals(responseFromService.getManufacturingDate(), washingMachineRequest.getManufacturingDate());
    }

//    @Override
//    public void updateWashingMachineById(String id, WashingMachineRequestDTO washingMachineDTO) {
//	Optional<WashingMachine> washingMachine = washingMachineRepo.findWashingMachineById(id);
//	if (washingMachine.isPresent()) {
//	    WashingMachine updatedWashingMachine = washingMachine.get();
//	    updatedWashingMachine.setCapacity(washingMachineDTO.getCapacity());
//	    updatedWashingMachine.setColor(washingMachineDTO.getColor());
//	    updatedWashingMachine.setDescription(washingMachineDTO.getDescription());
//	    updatedWashingMachine.setDryerIncorporated(washingMachineDTO.getDryerIncorporated());
//	    updatedWashingMachine.setManufacturingDate(washingMachineDTO.getManufacturingDate());
//	    washingMachineRepo.save(updatedWashingMachine);
//	} else {
//	    throw new EntityNotFoundException("No washing machine exists for given id.");
//	}
//    }

    @Test
    public void testUpdateWashingMachine() {
	// given
	String id = "d7cd23b8-test-470f-ac63-d8fb106f391e";

	WashingMachineRequestDTO washingMachineRequest = new WashingMachineRequestDTO();
	washingMachineRequest.setCapacity(12);
	washingMachineRequest.setColor("Black Noir");
	washingMachineRequest.setDescription("One of the best washing machines in the market.");
	washingMachineRequest.setManufacturingDate(LocalDateTime.of(2020, 12, 12, 15, 00, 00));
	washingMachineRequest.setDryerIncorporated(false);

	// when
	when(washingMachineRepository.findWashingMachineById(id)).thenReturn(Optional.of(washingMachine));
	when(washingMachineRepository.save(washingMachine)).thenReturn(ArgumentMatchers.any(WashingMachine.class));

	// then
	washingMachineService.updateWashingMachineById(id, washingMachineRequest);
    }

    @Test(expected = EntityNotFoundException.class)
    public void testUpdateWashingMachineViolationException() {
	// given
	String id = "d7cd23b8-test-470f-ac63-d8fb106f391e";

	WashingMachineRequestDTO washingMachineRequest = new WashingMachineRequestDTO();
	washingMachineRequest.setCapacity(12);
	washingMachineRequest.setColor("Black Noir");
	washingMachineRequest.setDescription("One of the best washing machines in the market.");
	washingMachineRequest.setManufacturingDate(LocalDateTime.of(2020, 12, 12, 15, 00, 00));
	washingMachineRequest.setDryerIncorporated(false);

	// when
	when(washingMachineRepository.findWashingMachineById(id)).thenReturn(Optional.empty());

	// then
	washingMachineService.updateWashingMachineById(id, washingMachineRequest);
    }

    @Test
    public void testDeleteWashingMachineById() {
	// when
	String id = "d7cd23b8-test-470f-ac63-d8fb106f391e";
	when(washingMachineRepository.findWashingMachineById(id)).thenReturn(Optional.of(washingMachine));
	doNothing().when(washingMachineRepository).delete(washingMachine);

	// then
	washingMachineService.deleteWashingMachineById(id);
    }

    @Test(expected = EntityNotFoundException.class)
    public void testDeleteWashingMachineByIdNotFound() {
	// given
	String id = "d7cd23b8-test-470f-ac63-d8fb106f391e";
	when(washingMachineRepository.findWashingMachineById(id)).thenReturn(Optional.empty());

	// when
	washingMachineService.deleteWashingMachineById(id);
    }
}