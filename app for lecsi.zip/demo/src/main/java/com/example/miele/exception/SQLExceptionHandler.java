package com.example.miele.exception;

import java.sql.SQLException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import lombok.extern.log4j.Log4j2;

@Log4j2
@ControllerAdvice
public class SQLExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(SQLException.class)
    public ResponseEntity<Object> sqlExceptionHandler(SQLException ex, WebRequest request) {
	StringBuilder builder = new StringBuilder();
	builder.append("sqlExceptionHandler() for request: ");
	builder.append(request.toString());
	builder.append(" the response error is: ");
	builder.append(ex.getMessage());
	log.error(builder.toString());
	return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
