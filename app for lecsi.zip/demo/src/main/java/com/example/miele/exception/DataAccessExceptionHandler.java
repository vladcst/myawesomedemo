package com.example.miele.exception;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import lombok.extern.log4j.Log4j2;

@Log4j2
@ControllerAdvice
public class DataAccessExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity<Object> dataAccessExceptionHandler(DataAccessException ex, WebRequest request) {
	StringBuilder builder = new StringBuilder();
	builder.append("dataAccessExceptionHandler() for request: ");
	builder.append(request.toString());
	builder.append(" the response error is: ");
	builder.append(ex.getMessage());
	log.error(builder.toString());
	if (ExceptionUtils.getCause(ex) instanceof ConstraintViolationException) {
	    log.error("ConstraintViolationException with root cause for the exception being: "
		    + ExceptionUtils.getRootCause(ex));
	} else if (ExceptionUtils.getCause(ex) instanceof DataIntegrityViolationException) {
	    log.error("DataIntegrityViolationException with root cause for the exception being: "
		    + ExceptionUtils.getRootCause(ex));
	}
	return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }
}