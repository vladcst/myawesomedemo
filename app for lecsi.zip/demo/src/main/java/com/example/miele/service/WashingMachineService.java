package com.example.miele.service;

import java.util.List;

import com.example.miele.dto.WashingMachineRequestDTO;
import com.example.miele.dto.WashingMachineResponseDTO;

public interface WashingMachineService {

    public WashingMachineResponseDTO findWashingMachineById(String id);

    public WashingMachineResponseDTO saveWashingMachine(WashingMachineRequestDTO washingMachineDTO);

    public void updateWashingMachineById(String id, WashingMachineRequestDTO washingMachineDTO);

    public void deleteWashingMachineById(String id);

    public List<WashingMachineResponseDTO> findAllWashingMachines();

}
