package com.example.miele.dto;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class WashingMachineResponseDTO {

    private String id;
    private String description;
    private String color;
    private LocalDateTime manufacturingDate;
    private Integer capacity;
    private Boolean dryerIncorporated;

    public Boolean isDryerIncorporated() {
	return this.dryerIncorporated;
    }

    public void setDryerIncorporated(Boolean dryerIncorporated) {
	this.dryerIncorporated = dryerIncorporated;
    }

    @Override
    public String toString() {
	StringBuilder builder = new StringBuilder();
	builder.append("WashingMachineResonseDTO [id=");
	builder.append(id);
	builder.append(", description=");
	builder.append(description);
	builder.append(", color=");
	builder.append(color);
	builder.append(", creationDate=");
	builder.append(manufacturingDate);
	builder.append(", capacity=");
	builder.append(capacity);
	builder.append(", isDryerIncorporated=");
	builder.append(dryerIncorporated);
	builder.append("]");

	return builder.toString();
    }

}
