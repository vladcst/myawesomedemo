package com.example.miele;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MieleApplication {

    public static void main(String[] args) {
	SpringApplication.run(MieleApplication.class, args);
    }

}
