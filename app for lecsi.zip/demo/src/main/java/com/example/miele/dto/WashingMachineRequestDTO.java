package com.example.miele.dto;

import java.time.LocalDateTime;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class WashingMachineRequestDTO {

    @NotBlank(message = "The description of the washing machine.")
    @Size(max = 128, message = "Maximum length is 128 characters")
    private String description;

    @NotBlank(message = "The color of the washing machine.")
    @Size(max = 128, message = "Maximum length is 52 characters")
    private String color;

    @NotNull(message = "The manufacturing date of the washing machine.")
    @Past(message = "The manufacturing date must be in the past.")
    private LocalDateTime manufacturingDate;

    @NotNull(message = "The capacity of the washing machine, expressed in kilograms.")
    @Min(value = 1, message = "Minimum capacity is 1 kilogram")
    @Max(value = 20, message = "Maximum capacity is 20 kilograms")
    private Integer capacity;

    @NotNull(message = "Conditional to check if a dryer is incorporated or not.")
    private Boolean dryerIncorporated;

    public Boolean isDryerIncorporated() {
	return this.dryerIncorporated;
    }

    public void setDryerIncorporated(Boolean dryerIncorporated) {
	this.dryerIncorporated = dryerIncorporated;
    }

    @Override
    public String toString() {
	StringBuilder builder = new StringBuilder();
	builder.append("WashingMachineRequestDTO [description=");
	builder.append(description);
	builder.append(", color=");
	builder.append(color);
	builder.append(", creationDate=");
	builder.append(manufacturingDate);
	builder.append(", capacity=");
	builder.append(capacity);
	builder.append(", isDryerIncorporated=");
	builder.append(dryerIncorporated);
	builder.append("]");
	return builder.toString();
    }

}
