package com.example.miele.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.GenericGenerator;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "WASHING_MACHINE")
public class WashingMachine implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "ID", updatable = false, nullable = false, columnDefinition = "BINARY(16)")
    private String id;

    @NotNull
    @Column(name = "DESCRIPTION")
    private String description;

    @NotNull
    @Column(name = "COLOR")
    private String color;

    @NotNull
    @Column(name = "MANUFACTURING_DATE")
    private LocalDateTime manufacturingDate;

    @NotNull
    @Column(name = "CAPACITY")
    private Integer capacity;

    @NotNull
    @Column(name = "DRYER_INCORPORATED")
    private Boolean dryerIncorporated;

    public Boolean isDryerIncorporated() {
	return this.dryerIncorporated;
    }

    public void setDryerIncorporated(Boolean dryerIncorporated) {
	this.dryerIncorporated = dryerIncorporated;
    }

    @Override
    public String toString() {
	StringBuilder builder = new StringBuilder();
	builder.append("WashingMachine [id=");
	builder.append(id);
	builder.append(", description=");
	builder.append(description);
	builder.append(", color=");
	builder.append(color);
	builder.append(", manufacturingDate=");
	builder.append(manufacturingDate);
	builder.append(", capacity=");
	builder.append(capacity);
	builder.append(", isDryerIncorporated=");
	builder.append(dryerIncorporated);
	builder.append("]");

	return builder.toString();
    }

}
