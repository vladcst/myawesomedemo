package com.example.miele.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;

import org.apache.commons.collections4.CollectionUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.miele.dto.WashingMachineRequestDTO;
import com.example.miele.dto.WashingMachineResponseDTO;
import com.example.miele.entity.WashingMachine;
import com.example.miele.repository.WashingMachineRepository;
import com.example.miele.service.WashingMachineService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
@Transactional
public class WashingMachineServiceImpl implements WashingMachineService {

    @Autowired
    private WashingMachineRepository washingMachineRepo;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public WashingMachineResponseDTO findWashingMachineById(String id) {
	Optional<WashingMachine> washingMachine = washingMachineRepo.findWashingMachineById(id);
	if (washingMachine.isPresent()) {
	    return modelMapper.map(washingMachine.get(), WashingMachineResponseDTO.class);
	} else {
	    throw new EntityNotFoundException("No washing machine exists for given id.");
	}
    }

    @Override
    public List<WashingMachineResponseDTO> findAllWashingMachines() {
	List<WashingMachineResponseDTO> response = new ArrayList<>();
	List<WashingMachine> washingMachines = washingMachineRepo.findAll();
	if (!CollectionUtils.isEmpty(washingMachines)) {
	    response = washingMachines.stream().map(x -> modelMapper.map(x, WashingMachineResponseDTO.class))
		    .collect(Collectors.toList());
	}
	return response;
    }

    @Override
    public WashingMachineResponseDTO saveWashingMachine(WashingMachineRequestDTO washingMachineDTO) {
	log.info(modelMapper.map(washingMachineDTO, WashingMachine.class));
	WashingMachine savedWashingMachine = washingMachineRepo
		.save(modelMapper.map(washingMachineDTO, WashingMachine.class));
	return modelMapper.map(savedWashingMachine, WashingMachineResponseDTO.class);
    }

    @Override
    public void updateWashingMachineById(String id, WashingMachineRequestDTO washingMachineDTO) {
	Optional<WashingMachine> washingMachine = washingMachineRepo.findWashingMachineById(id);
	if (washingMachine.isPresent()) {
	    WashingMachine updatedWashingMachine = washingMachine.get();
	    updatedWashingMachine.setCapacity(washingMachineDTO.getCapacity());
	    updatedWashingMachine.setColor(washingMachineDTO.getColor());
	    updatedWashingMachine.setDescription(washingMachineDTO.getDescription());
	    updatedWashingMachine.setDryerIncorporated(washingMachineDTO.getDryerIncorporated());
	    updatedWashingMachine.setManufacturingDate(washingMachineDTO.getManufacturingDate());
	    washingMachineRepo.save(updatedWashingMachine);
	} else {
	    throw new EntityNotFoundException("No washing machine exists for given id.");
	}
    }

    @Override
    public void deleteWashingMachineById(String id) {
	Optional<WashingMachine> washingMachine = washingMachineRepo.findWashingMachineById(id);
	if (washingMachine.isPresent()) {
	    washingMachineRepo.delete(washingMachine.get());
	} else {
	    throw new EntityNotFoundException("No washing machine exists for given id.");
	}
    }

}