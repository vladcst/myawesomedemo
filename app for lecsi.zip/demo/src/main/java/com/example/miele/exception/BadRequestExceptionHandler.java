package com.example.miele.exception;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import lombok.extern.log4j.Log4j2;

@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
@Log4j2
public class BadRequestExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Object> methodArgumentNotValidException(MethodArgumentNotValidException ex) {
	log.error("handleMethodArgumentNotValid(): " + ex);
	ex.getBindingResult().getAllErrors().forEach((error) -> {
	    String fieldName = ((FieldError) error).getField();
	    String errorMessage = error.getDefaultMessage();
	    StringBuilder builder = new StringBuilder();
	    builder.append("handleMethodArgumentNotValid() error for fieldname: ");
	    builder.append(fieldName);
	    builder.append(" with the error: ");
	    builder.append(errorMessage);
	    log.error(builder.toString());
	});
	return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex) {
	log.error("handleHttpMediaTypeNotSupported(): " + ex);
	String unsupported = "Unsupported content type: " + ex.getContentType();
	String supported = "Supported content types: " + MediaType.toString(ex.getSupportedMediaTypes());
	StringBuilder builder = new StringBuilder();
	builder.append("handleHttpMediaTypeNotSupported() unsupported content type found: ");
	builder.append(unsupported);
	builder.append(", supported content types are: ");
	builder.append(supported);
	log.error(builder.toString());
	return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex) {
	log.error("handleHttpMessageNotReadable(): " + ex);
	Throwable mostSpecificCause = ex.getMostSpecificCause();
	if (mostSpecificCause != null) {
	    String exceptionName = mostSpecificCause.getClass().getName();
	    String message = mostSpecificCause.getMessage();
	    StringBuilder builder = new StringBuilder();
	    builder.append("handleHttpMessageNotReadable() exception found: ");
	    builder.append(exceptionName);
	    builder.append(" with message: ");
	    builder.append(message);
	    log.error(builder.toString());
	} else {
	    log.error("handleHttpMessageNotReadable() exception found: " + ex.getMessage());
	}
	return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

}