package com.example.miele.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.miele.dto.WashingMachineRequestDTO;
import com.example.miele.dto.WashingMachineResponseDTO;
import com.example.miele.service.WashingMachineService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
public class WashingMachineController {

    @Autowired
    private WashingMachineService washingMachineService;

    @GetMapping("/washingMachine/{id}")
    public ResponseEntity<WashingMachineResponseDTO> getWashingMachineById(@PathVariable final String id) {
	log.info("getWashingMachineById() started with id: " + id);
	WashingMachineResponseDTO response = washingMachineService.findWashingMachineById(id);
	log.info("getWashingMachineById() found washing machine: " + response);
	return new ResponseEntity<WashingMachineResponseDTO>(response, HttpStatus.OK);
    }

    @GetMapping("/washingMachine")
    public ResponseEntity<List<WashingMachineResponseDTO>> getWashingMachines() {
	log.info("getWashingMachines() started.");
	List<WashingMachineResponseDTO> responseList = washingMachineService.findAllWashingMachines();
	if (CollectionUtils.isEmpty(responseList)) {
	    log.info("getWashingMachines(): no washing machines found.");
	    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	} else {
	    return new ResponseEntity<List<WashingMachineResponseDTO>>(responseList, HttpStatus.OK);
	}
    }

    @PostMapping("/washingMachine")
    public ResponseEntity<WashingMachineResponseDTO> saveWashingMachine(
	    @RequestBody @Valid WashingMachineRequestDTO washingMachineDTO) {
	log.info("saveWashingMachine() started for the following washing machine = " + washingMachineDTO);
	WashingMachineResponseDTO createdWashingMachine = washingMachineService.saveWashingMachine(washingMachineDTO);
	log.info("saveWashingMachine() completed successfully.");
	return new ResponseEntity<WashingMachineResponseDTO>(createdWashingMachine, HttpStatus.CREATED);
    }

    @PutMapping("/washingMachine/{id}")
    public ResponseEntity<Void> updateWashingMachine(@PathVariable final String id,
	    @RequestBody @Valid WashingMachineRequestDTO washingMachineDTO) {
	log.info("updateWashingMachine() started for the following washing machine = " + washingMachineDTO);
	washingMachineService.updateWashingMachineById(id, washingMachineDTO);
	log.info("updateWashingMachine() completed successfully");
	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @DeleteMapping("/washingMachine/{id}")
    public ResponseEntity<Void> deleteWashingMachine(@PathVariable final String id) {
	log.info("deleteWashingMachine() started with the id = " + id);
	washingMachineService.deleteWashingMachineById(id);
	log.info("deleteWashingMachine() completed successfully");
	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}