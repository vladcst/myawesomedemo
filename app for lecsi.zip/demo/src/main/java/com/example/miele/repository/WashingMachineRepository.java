package com.example.miele.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.miele.entity.WashingMachine;

@Repository
public interface WashingMachineRepository extends JpaRepository<WashingMachine, String> {

    @Query("Select wm From WashingMachine wm Where wm.id = :id")
    public Optional<WashingMachine> findWashingMachineById(@Param("id") String id);

}
